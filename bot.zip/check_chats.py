import asyncio
import os
from dotenv import load_dotenv
from aiogram import Bot
from datetime import datetime

load_dotenv()
TOKEN = os.getenv("BOT_TOKEN")
CHANNEL_MSK_ID = int(os.getenv("CHANNEL_MSK_ID"))
CHANNEL_PODOLSK_ID = int(os.getenv("CHANNEL_PODOLSK_ID"))
NOTIFY_CHAT_MSK_ID = int(os.getenv("NOTIFY_CHAT_MSK_ID"))
NOTIFY_CHAT_PODOLSK_ID = int(os.getenv("NOTIFY_CHAT_PODOLSK_ID"))

bot = Bot(token=TOKEN)

chats = {
    "CHANNEL_MSK_ID": CHANNEL_MSK_ID,
    "CHANNEL_PODOLSK_ID": CHANNEL_PODOLSK_ID,
    "NOTIFY_CHAT_MSK_ID": NOTIFY_CHAT_MSK_ID,
    "NOTIFY_CHAT_PODOLSK_ID": NOTIFY_CHAT_PODOLSK_ID,
}

async def check_chats():
    try:
        # Проверяем информацию о боте
        me = await bot.get_me()
        print(f"[{datetime.now()}] Информация о боте:")
        print(f"  ID: {me.id}")
        print(f"  Имя: {me.first_name}")
        print(f"  Username: @{me.username}")
        print(f"  IsBot: {me.is_bot}\n")

        # Проверяем каждый чат/канал
        for chat_name, chat_id in chats.items():
            print(f"Проверка {chat_name} ({chat_id})...")
            try:
                chat = await bot.get_chat(chat_id)
                print(f"  ✅ Доступен!")
                print(f"  Тип: {chat.type}")
                print(f"  Название: {chat.title}")
                
                # Пытаемся получить список администраторов
                try:
                    admins = await bot.get_chat_administrators(chat_id)
                    print(f"  Администраторов: {len(admins)}")
                    for admin in admins[:3]:  # Показываем первых 3
                        print(f"    - {admin.user.first_name} (@{admin.user.username if admin.user.username else 'N/A'})")
                    if len(admins) > 3:
                        print(f"    ... и ещё {len(admins) - 3}")
                except Exception as e:
                    print(f"  ⚠️ Не удалось получить администраторов: {e}")
                
                # Получаем количество участников (если возможно)
                try:
                    member_count = await bot.get_chat_member_count(chat_id)
                    print(f"  Участников: {member_count}")
                except Exception as e:
                    print(f"  ⚠️ Не удалось получить количество участников: {e}")
                
            except Exception as e:
                print(f"  ❌ Ошибка доступа: {e}")
            
            print()

    except Exception as e:
        print(f"Критическая ошибка: {e}")
    
    finally:
        await bot.session.close()

if __name__ == "__main__":
    print("=== Проверка доступности чатов и каналов ===\n")
    asyncio.run(check_chats())
