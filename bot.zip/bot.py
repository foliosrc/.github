import sys
import asyncio

# event loop win32
if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())
    
# Создаём и устанавливаем event loop
loop = asyncio.new_event_loop()
asyncio.set_event_loop(loop)

import random
import os
import traceback
from aiogram import Bot, Dispatcher
from aiogram.types import InputMediaPhoto
from aiogram.enums.parse_mode import ParseMode
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from flask import Flask
from threading import Thread
from dotenv import load_dotenv
from aiogram.types import FSInputFile
from datetime import datetime

load_dotenv()
TOKEN = os.getenv("BOT_TOKEN")
CHANNEL_MSK_ID = int(os.getenv("CHANNEL_MSK_ID"))
CHANNEL_PODOLSK_ID = int(os.getenv("CHANNEL_PODOLSK_ID"))
NOTIFY_CHAT_MSK_ID = int(os.getenv("NOTIFY_CHAT_MSK_ID"))
NOTIFY_CHAT_PODOLSK_ID = int(os.getenv("NOTIFY_CHAT_PODOLSK_ID"))
ADMIN_USERNAME_MSK = os.getenv("ADMIN_USERNAME_MSK", "")
ADMIN_USERNAME_PODOLSK = os.getenv("ADMIN_USERNAME_PODOLSK", "")

print(f"[Конфиг загружен]")
print(f"  CHANNEL_MSK_ID: {CHANNEL_MSK_ID}")
print(f"  CHANNEL_PODOLSK_ID: {CHANNEL_PODOLSK_ID}")
print(f"  NOTIFY_CHAT_MSK_ID: {NOTIFY_CHAT_MSK_ID}")
print(f"  NOTIFY_CHAT_PODOLSK_ID: {NOTIFY_CHAT_PODOLSK_ID}")
print(f"  ADMIN_USERNAME_MSK: {ADMIN_USERNAME_MSK}")
print(f"  ADMIN_USERNAME_PODOLSK: {ADMIN_USERNAME_PODOLSK}")

bot = Bot(token=TOKEN)
dp = Dispatcher()
scheduler = AsyncIOScheduler(timezone="Europe/Moscow")

flask_app = Flask(__name__)

@flask_app.route('/')
def home():
    return "Бот работает на Render!"

# Шансы на выпадение наград от 1 до 5
REWARD_WEIGHTS = [30, 25, 15, 10, 8]

async def send_daily_prize():

    try:
        pc_number = random.randint(1, 38)
        reward_number = random.choices(range(1, 6), weights=REWARD_WEIGHTS, k=1)[0]

        digit_path = f"digits/{pc_number}.jpg"
        gift_path = f"gifts/{reward_number}.jpg"

        # Текст для каналов
        channel_text = (
            f"🎉💻 В ежедневной акции «Счастливый компьютер» сегодня удача улыбается ПК №{pc_number}\n\n"
            "🎯 Колесо фортуны выбрало для него приз!\n\n"
            "📌 Хочешь оказаться на его месте?\n"
            "📅Напоминаем: каждый день в 18:00 один из ПК становится счастливым.\n"
            "Успей занять место — вдруг повезёт именно тебе!\n"
            "Подробности у администраторов клуба."
        )
        
        # Текст для чатов администраторов
        admin_text = f"Гость за {pc_number} ПК выиграл приз {reward_number}"
    
        media = [
            InputMediaPhoto(media=FSInputFile(digit_path), caption=channel_text, parse_mode=ParseMode.HTML),
            InputMediaPhoto(media=FSInputFile(gift_path))
        ]

        # Отправляем в оба канала
        await bot.send_media_group(chat_id=CHANNEL_MSK_ID, media=media)
        print(f"[{datetime.now()}] Пост отправлен в канал МСК")
        
        await bot.send_media_group(chat_id=CHANNEL_PODOLSK_ID, media=media)
        print(f"[{datetime.now()}] Пост отправлен в канал Подольск")
        
        # Отправляем в чат администраторов МСК с упоминаниями
        msk_admin_msg = admin_text
        if ADMIN_USERNAME_MSK:
            msk_admin_msg += f"\n\n{ADMIN_USERNAME_MSK}"
        await bot.send_photo(chat_id=NOTIFY_CHAT_MSK_ID, photo=FSInputFile(gift_path), caption=msk_admin_msg)
        print(f"[{datetime.now()}] Уведомление отправлено в чат администраторов МСК")
        
        # Отправляем в чат администраторов Подольска с упоминаниями
        podolsk_admin_msg = admin_text
        if ADMIN_USERNAME_PODOLSK:
            podolsk_admin_msg += f"\n\n{ADMIN_USERNAME_PODOLSK}"
        await bot.send_photo(chat_id=NOTIFY_CHAT_PODOLSK_ID, photo=FSInputFile(gift_path), caption=podolsk_admin_msg)
        print(f"[{datetime.now()}] Уведомление отправлено в чат администраторов Подольска")

        print(f"[{datetime.now()}] Полный цикл выполнен! Победитель - ПК№{pc_number}, приз {reward_number}")

    except Exception as e:
        traceback.print_exc()
        print(f"[{datetime.now()}] Ошибка при отправке: {e}")
    
def run_flask():
    flask_app.run(host='0.0.0.0', port=int(os.environ.get("PORT", 5000)))

def start_flask():
    Thread(target=run_flask).start()

async def send_startup_notification():
    """Отправляет уведомление о запуске бота в чаты администраторов"""
    try:
        startup_text = (
            "✅ Бот запущен и готов к работе!\n\n"
            "⏰ Ожидаем начала розыгрыша в 18:00\n"
            "🎯 Все системы работают корректно."
        )
        
        await bot.send_message(chat_id=NOTIFY_CHAT_MSK_ID, text=startup_text)
        print(f"[{datetime.now()}] Уведомление о запуске отправлено в чат МСК")
        
        await bot.send_message(chat_id=NOTIFY_CHAT_PODOLSK_ID, text=startup_text)
        print(f"[{datetime.now()}] Уведомление о запуске отправлено в чат Подольска")
        
    except Exception as e:
        traceback.print_exc()
        print(f"[{datetime.now()}] Ошибка при отправке уведомления о запуске: {e}")

async def main():
    start_flask()
    await send_startup_notification()
    scheduler.add_job(send_daily_prize, "cron", hour=18, minute=0)
    scheduler.start()
    print("Планировщик запущен. Ожидание 18:00...")

    while True:
        await asyncio.sleep(3600)

if __name__ == "__main__":
    try:
        loop.run_until_complete(main())
    except KeyboardInterrupt:
        print("\nБот остановлен")
    finally:
        loop.close()
