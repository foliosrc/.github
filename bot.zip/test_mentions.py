import sys
import asyncio

# Очень критично: создаём event loop ДО ВСЕГО
if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())
    
# Создаём и устанавливаем event loop
loop = asyncio.new_event_loop()
asyncio.set_event_loop(loop)

import os
from dotenv import load_dotenv
from aiogram import Bot
from datetime import datetime

load_dotenv()
TOKEN = os.getenv("BOT_TOKEN")
NOTIFY_CHAT_MSK_ID = int(os.getenv("NOTIFY_CHAT_MSK_ID"))
NOTIFY_CHAT_PODOLSK_ID = int(os.getenv("NOTIFY_CHAT_PODOLSK_ID"))
ADMIN_USERNAME_MSK = os.getenv("ADMIN_USERNAME_MSK", "")
ADMIN_USERNAME_PODOLSK = os.getenv("ADMIN_USERNAME_PODOLSK", "")

bot = Bot(token=TOKEN)

async def test_mentions():

    try:
        print("=" * 60)
        print("🧪 ТЕСТИРОВАНИЕ УПОМИНАНИЙ АДМИНИСТРАТОРОВ В ЧАТАХ")
        print("=" * 60)
        
        test_text = "Если пингуется, на ответ лайкните сообщение. Надо понимать, доходит ли связь до администраторов.\n" \
                    f"Время теста: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        
        # Тестируем чат МСК
        print(f"\n🏙️ Тестирование чата МСК ({NOTIFY_CHAT_MSK_ID})...")
        msk_msg = test_text
        if ADMIN_USERNAME_MSK:
            msk_msg += f"\n\nПинг: {ADMIN_USERNAME_MSK}"
        else:
            msk_msg += "\n\n⚠️ Внимание: ADMIN_USERNAME_MSK не задан в .env"
        await bot.send_message(chat_id=NOTIFY_CHAT_MSK_ID, text=msk_msg)
        print(f"✅ Сообщение отправлено в чат МСК")
        
        # Небольшая пауза между отправками
        await asyncio.sleep(1)
        
        # Тестируем чат Подольска
        print(f"\n🏙️ Тестирование чата Подольска ({NOTIFY_CHAT_PODOLSK_ID})...")
        podolsk_msg = test_text
        if ADMIN_USERNAME_PODOLSK:
            podolsk_msg += f"\n\nПинг: {ADMIN_USERNAME_PODOLSK}"
        else:
            podolsk_msg += "\n\n⚠️ Внимание: ADMIN_USERNAME_PODOLSK не задан в .env"
        await bot.send_message(chat_id=NOTIFY_CHAT_PODOLSK_ID, text=podolsk_msg)
        print(f"✅ Сообщение отправлено в чат Подольска")
        
        print("\n" + "=" * 60)
        print("✅ ТЕСТИРОВАНИЕ ЗАВЕРШЕНО УСПЕШНО")
        print("=" * 60)
        
    except Exception as e:
        print(f"\n❌ Ошибка: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        await bot.session.close()

if __name__ == "__main__":
    try:
        loop.run_until_complete(test_mentions())
    except KeyboardInterrupt:
        print("\nТестирование остановлено")
    finally:
        loop.close()
